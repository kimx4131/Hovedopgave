-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Vært: localhost:8889
-- Genereringstid: 23. 05 2020 kl. 09:52:34
-- Serverversion: 5.7.26
-- PHP-version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tool`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `boligliste`
--

CREATE TABLE `boligliste` (
  `id_bolig` int(11) NOT NULL,
  `lejlnr` int(10) NOT NULL,
  `id_projekt` int(10) NOT NULL,
  `postnr` varchar(10) NOT NULL,
  `vejnavn` varchar(255) NOT NULL,
  `husnr` varchar(255) NOT NULL,
  `etage` varchar(10) NOT NULL,
  `side` varchar(10) NOT NULL,
  `bypost` varchar(255) NOT NULL,
  `kvm` varchar(255) NOT NULL,
  `vaerelser` varchar(10) NOT NULL,
  `lejeraw` int(255) NOT NULL,
  `lejegebyr` varchar(255) NOT NULL,
  `acontovarme` int(255) NOT NULL,
  `acontovand` int(255) NOT NULL,
  `depositum` int(255) NOT NULL,
  `forudbetalt` int(255) NOT NULL,
  `toilet` varchar(10) NOT NULL,
  `bad` varchar(10) NOT NULL,
  `ledigpr` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `plantegning` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `depotrum` varchar(255) NOT NULL,
  `altan` varchar(255) NOT NULL,
  `terasse` varchar(255) NOT NULL,
  `elevator` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data dump for tabellen `boligliste`
--

INSERT INTO `boligliste` (`id_bolig`, `lejlnr`, `id_projekt`, `postnr`, `vejnavn`, `husnr`, `etage`, `side`, `bypost`, `kvm`, `vaerelser`, `lejeraw`, `lejegebyr`, `acontovarme`, `acontovand`, `depositum`, `forudbetalt`, `toilet`, `bad`, `ledigpr`, `status`, `plantegning`, `url`, `depotrum`, `altan`, `terasse`, `elevator`) VALUES
(1, 1, 10, '2800', 'Lyngby Hovedegade', '4', '0', 'th', 'Lyngby', '100', '3', 10000, '12000', 1000, 1000, 30000, 10000, '1', '1', '2015-04-20', '2', 'tom', 'NULL', '1', '1', '1', '1'),
(2, 1, 10, '2860', 'Gladsaxevej', '386', '1', 'lejl. 1', 'Soeborg', '106', '3', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'tom', 'tom', '1', '0', '1', '1'),
(3, 2, 10, '2860', 'Gladsaxevej', '386', '1', 'lejl. 2', 'Soeborg', '78', '2', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '1', 'tom', 'tom', '1', '0', '1', '1'),
(4, 1, 10, '2860', 'Gladsaxevej', '386', '1', 'lejl. 1', 'Soeborg', '106', '3', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '1', 'tom', 'tom', '1', '0', '1', '1'),
(5, 2, 10, '2860', 'Gladsaxevej', '386', '1', 'lejl. 2', 'Soeborg', '78', '2', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'tom', 'tom', '1', '0', '1', '1'),
(6, 1, 12, '2860', 'Gladsaxevej', '386', '1', 'lejl. 1', 'Soeborg', '106', '3', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '3', 'tom', 'tom', '1', '0', '1', '1'),
(7, 2, 12, '2860', 'Søborgvej', '386', '1', 'lejl. 2', 'Soeborg', '78', '2', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'tom', 'tom', '1', '0', '1', '1'),
(12, 1, 13, '2860', 'Gladsaxevej', '386', '', '', 'Soeborg', '106', '3', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'tom', 'tom', '1', '0', '1', '1'),
(13, 2, 13, '2860', 'Gladsaxevej', '386', '', '', 'Soeborg', '78', '2', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'tom', 'tom', '1', '0', '1', '1'),
(14, 136, 11, '2860', 'Gladsaxevej', '400A', '1', 'lejl. 1', 'Soeborg', '106', '3', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-D-4-2---Lejlighedstype-I.jpg', 'https://kragesand.dk/', '1', '2', '0', '1'),
(15, 137, 11, '2860', 'Gladsaxevej', '400A', '1', 'lejl. 2', 'Soeborg', '78', '2', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-D-4-1---Lejlighedstype-J.jpg', 'https://kragesand.dk/', '2', '0', '2', '1'),
(16, 138, 11, '2860', 'Gladsaxevej', '400A', '1', 'lejl. 3', 'Soeborg', '55', '4', 12900, '14313', 707, 442, 3, 1, '2', '1', '2015-03-20', '2', 'MFB---400-D-3-3---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(17, 139, 11, '2860', 'Gladsaxevej', '400A', '2', 'lejl. 4', 'Soeborg', '93', '3', 11500, '12540', 520, 325, 3, 1, '2', '2', '2015-03-20', '2', 'MFB---400-D-3-3---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(18, 140, 11, '2860', 'Gladsaxevej', '400A', '2', 'lejl. 5', 'Soeborg', '27', '2', 12900, '14313', 707, 442, 3, 1, '3', '2', '2015-03-20', '1', 'MFB---400-D-4-2---Lejlighedstype-I.jpg', 'https://kragesand.dk/', 'Loft', '1', '1', '1'),
(19, 141, 11, '2860', 'Gladsaxevej', '400A', '2', 'lejl. 6', 'Soeborg', '49', '3', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-D-4-1---Lejlighedstype-J.jpg', 'https://kragesand.dk/', '1', '0', '0', '1'),
(20, 142, 11, '2860', 'Gladsaxevej', '400A', '3', 'lejl. 7', 'Soeborg', '39', '4', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-D-3-3---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(21, 143, 11, '2860', 'Gladsaxevej', '400A', '3', 'lejl. 8', 'Soeborg', '103', '5', 11500, '12540', 520, 325, 3, 1, '2', '1', '2015-03-20', '2', 'MFB---400-D-3-2---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '2', '2', '1', '1'),
(22, 144, 11, '2860', 'Gladsaxevej', '400A', '3', 'lejl. 9', 'Soeborg', '98', '5', 12900, '14313', 707, 442, 3, 1, '2', '2', '2015-03-20', '3', 'MFB---400-D-3-1---Lejlighedstype-C.jpg', 'https://kragesand.dk/', '1', '0', '2', '1'),
(23, 145, 11, '2860', 'Gladsaxevej', '400A', '4', 'lejl. 10', 'Soeborg', '83', '3', 11500, '12540', 520, 325, 3, 1, '3', '2', '2015-03-20', '2', 'MFB---400-D-2-3---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(24, 146, 11, '2860', 'Gladsaxevej', '400A', '4', 'lejl. 11', 'Soeborg', '73', '3', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-D-2-2---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '1', '1', '1', '1'),
(25, 147, 11, '2860', 'Gladsaxevej', '400B', '1', 'lejl. 12', 'Soeborg', '104', '2', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-D-2-1---Lejlighedstype-C.jpg', 'https://kragesand.dk/', '2', '0', '1', '1'),
(26, 148, 11, '2860', 'Gladsaxevej', '400B', '1', 'lejl. 13', 'Soeborg', '106', '3', 12900, '14313', 707, 442, 3, 1, '2', '1', '2015-03-20', '2', 'MFB---400-D-1-3---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '1', '0', '0', '1'),
(27, 149, 11, '2860', 'Gladsaxevej', '400B', '1', 'lejl. 14', 'Soeborg', '78', '2', 11500, '12540', 520, 325, 3, 1, '2', '2', '2015-03-20', '2', 'MFB---400-D-1-2---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(28, 150, 11, '2860', 'Gladsaxevej', '400B', '2', 'lejl. 15', 'Soeborg', '55', '4', 12900, '14313', 707, 442, 3, 1, '3', '2', '2015-03-20', '2', 'MFB---400-D-1-1---Lejlighedstype-C.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(29, 151, 11, '2860', 'Gladsaxevej', '400B', '2', 'lejl. 16', 'Soeborg', '93', '3', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-C-4-3---Lejlighedstype-I.jpg', 'https://kragesand.dk/', '1', '0', '2', '1'),
(30, 152, 11, '2860', 'Gladsaxevej', '400B', '2', 'lejl. 17', 'Soeborg', '27', '2', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-C-4-2---Lejlighedstype-L.jpg', 'https://kragesand.dk/', '1', '1', '1', '1'),
(31, 153, 11, '2860', 'Gladsaxevej', '400B', '3', 'lejl. 18', 'Soeborg', '49', '3', 11500, '12540', 520, 325, 3, 1, '2', '1', '2015-03-20', '3', 'MFB---400-C-4-1---Lejlighedstype-K.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(32, 154, 11, '2860', 'Gladsaxevej', '400B', '3', 'lejl. 19', 'Soeborg', '39', '4', 12900, '14313', 707, 442, 3, 1, '2', '2', '2015-03-20', '1', 'MFB---400-C-3-4---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '2', '2', '1', '1'),
(33, 155, 11, '2860', 'Gladsaxevej', '400B', '3', 'lejl. 20', 'Soeborg', '103', '5', 11500, '12540', 520, 325, 3, 1, '3', '2', '2015-03-20', '2', 'MFB---400-C-3-3---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '1', '0', '0', '1'),
(34, 156, 11, '2860', 'Gladsaxevej', '400B', '4', 'lejl. 21', 'Soeborg', '98', '5', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-C-3-2---Lejlighedstype-H.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(35, 157, 11, '2860', 'Gladsaxevej', '400B', '4', 'lejl. 22', 'Soeborg', '83', '3', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-C-3-1---Lejlighedstype-G.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(36, 158, 11, '2860', 'Gladsaxevej', '400C', '1', 'lejl. 23', 'Soeborg', '73', '3', 12900, '14313', 707, 442, 3, 1, '2', '1', '2015-03-20', '2', 'MFB---400-C-2-4---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(37, 159, 11, '2860', 'Gladsaxevej', '400C', '1', 'lejl. 24', 'Soeborg', '104', '2', 11500, '12540', 520, 325, 3, 1, '2', '2', '2015-03-20', '2', 'MFB---400-C-2-3---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '1', '1', '2', '1'),
(38, 160, 11, '2860', 'Gladsaxevej', '400C', '1', 'lejl. 25', 'Soeborg', '106', '3', 12900, '14313', 707, 442, 3, 1, '3', '2', '2015-03-20', '1', 'MFB---400-C-2-2---Lejlighedstype-H.jpg', 'https://kragesand.dk/', '2', '0', '1', '1'),
(39, 161, 11, '2860', 'Gladsaxevej', '400C', '0', 'lejl. 26', 'Soeborg', '78', '2', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-C-2-1---Lejlighedstype-G.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(40, 162, 11, '2860', 'Gladsaxevej', '400C', '2', 'lejl. 27', 'Soeborg', '55', '4', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-C-1-4---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(41, 163, 11, '2860', 'Gladsaxevej', '400C', '2', 'lejl. 28', 'Soeborg', '93', '3', 11500, '12540', 520, 325, 3, 1, '2', '1', '2015-03-20', '1', 'MFB---400-C-1-3---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '1', '0', '0', '1'),
(42, 164, 11, '2860', 'Gladsaxevej', '400C', '2', 'lejl. 29', 'Soeborg', '27', '2', 12900, '14313', 707, 442, 3, 1, '2', '2', '2015-03-20', '3', 'MFB---400-C-1-2---Lejlighedstype-H.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(43, 165, 11, '2860', 'Gladsaxevej', '400C', '2', 'lejl. 30', 'Soeborg', '49', '3', 11500, '12540', 520, 325, 3, 1, '3', '2', '2015-03-20', '2', 'MFB---400-C-1-1---Lejlighedstype-G.jpg', 'https://kragesand.dk/', '1', '1', '1', '1'),
(44, 166, 11, '2860', 'Gladsaxevej', '400C', '3', 'lejl. 31', 'Soeborg', '39', '4', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-B-4-2---Lejlighedstype-J.jpg', 'https://kragesand.dk/', '2', '0', '1', '1'),
(45, 167, 11, '2860', 'Gladsaxevej', '400C', '3', 'lejl. 32', 'Soeborg', '103', '5', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-B-4-1---Lejlighedstype-I.jpg', 'https://kragesand.dk/', '1', '2', '2', '1'),
(46, 168, 11, '2860', 'Gladsaxevej', '400C', '3', 'lejl. 33', 'Soeborg', '98', '5', 12900, '14313', 707, 442, 3, 1, '2', '1', '2015-03-20', '2', 'MFB---400-B-3-3---Lejlighedstype-C.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(47, 169, 11, '2860', 'Gladsaxevej', '400C', '3', 'lejl. 34', 'Soeborg', '83', '3', 11500, '12540', 520, 325, 3, 1, '2', '2', '2015-03-20', '1', 'MFB---400-B-3-2---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(48, 170, 11, '2860', 'Gladsaxevej', '400C', '4', 'lejl. 35', 'Soeborg', '73', '3', 12900, '14313', 707, 442, 3, 1, '3', '2', '2015-03-20', '2', 'MFB---400-B-3-1---Lejlighedstype-A.jpg', 'https://kragesand.dk/', 'Kaelder', '0', '1', '1'),
(49, 171, 11, '2860', 'Gladsaxevej', '400C', '4', 'lejl. 36', 'Soeborg', '104', '2', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-B-2-3---Lejlighedstype-C.jpg', 'https://kragesand.dk/', '1', '0', '0', '1'),
(50, 172, 11, '2860', 'Gladsaxevej', '400C', '4', 'lejl. 37', 'Soeborg', '106', '3', 11500, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-B-2-2---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '1', '1', '1', '1'),
(51, 173, 11, '2860', 'Gladsaxevej', '400D', '1', 'lejl. 38', 'Soeborg', '78', '2', 11500, '12540', 520, 325, 3, 1, '2', '1', '2015-03-20', '2', 'MFB---400-B-2-1---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(52, 174, 11, '2860', 'Gladsaxevej', '400D', '1', 'lejl. 39', 'Soeborg', '55', '4', 12900, '14313', 707, 442, 3, 1, '2', '2', '2015-03-20', '3', 'MFB---400-B-1-3---Lejlighedstype-C.jpg', 'https://kragesand.dk/', '1', '0', '2', '1'),
(53, 175, 11, '2860', 'Gladsaxevej', '400D', '2', 'lejl. 40', 'Soeborg', '93', '3', 11500, '12540', 520, 325, 3, 1, '3', '2', '2015-03-20', '2', 'MFB---400-B-1-2---Lejlighedstype-B.jpg', 'https://kragesand.dk/', 'Loft', '2', '1', '1'),
(54, 176, 11, '2860', 'Gladsaxevej', '400D', '2', 'lejl. 41', 'Soeborg', '27', '2', 12900, '14313', 707, 442, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-B-1-1---Lejlighedstype-A.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(55, 177, 11, '2860', 'Gladsaxevej', '400D', '2', 'lejl. 42', 'Soeborg', '49', '1', 11500, '12540', 520, 325, 3, 1, '1', '1', '2015-03-20', '2', 'MFB---400-A-4-2---Lejlighedstype-J.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(56, 178, 11, '2860', 'Gladsaxevej', '400D', '3', 'lejl. 43', 'Soeborg', '39', '4', 12900, '14313', 707, 442, 3, 1, '2', '1', '2015-03-20', '2', 'MFB---400-A-4-1---Lejlighedstype-I.jpg', 'https://kragesand.dk/', '1', '1', '1', '1'),
(57, 179, 11, '2860', 'Gladsaxevej', '400D', '3', 'lejl. 44', 'Soeborg', '103', '5', 11500, '12540', 520, 325, 3, 1, '2', '2', '2015-03-20', '1', 'MFB---400-A-3-3---Lejlighedstype-C.jpg', 'https://kragesand.dk/', '1', '2', '0', '1'),
(58, 180, 11, '2860', 'Gladsaxevej', '400D', '3', 'lejl. 45', 'Soeborg', '98', '5', 12900, '14313', 707, 442, 3, 1, '3', '2', '2015-03-20', '2', 'MFB---400-A-3-2---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '1', '0', '1', '1'),
(59, 181, 11, '2860', 'Gladsaxevej', '400D', '4', 'lejl. 46', 'Soeborg', '83', '3', 11500, '12540', 520, 325, 3, 1, '2', '1', '2015-03-20', '2', 'MFB---400-A-3-1---Lejlighedstype-A.jpg', 'https://kragesand.dk/', 'Kaelder', '0', '1', '0'),
(60, 182, 11, '2860', 'Gladsaxevej', '400D', '4', 'lejl. 47', 'Soeborg', '73', '3', 12900, '14313', 707, 442, 3, 1, '2', '2', '2015-03-20', '2', 'MFB---400-A-2-3---Lejlighedstype-C.jpg', 'https://kragesand.dk/', '1', '0', '2', '1'),
(61, 183, 11, '2860', 'Gladsaxevej', '400D', '4', 'lejl. 48', 'Soeborg', '104', '2', 11500, '12540', 520, 325, 3, 1, '3', '2', '2015-03-20', '2', 'MFB---400-A-2-2---Lejlighedstype-B.jpg', 'https://kragesand.dk/', '1', '0', '1', '1');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `bruger`
--

CREATE TABLE `bruger` (
  `id_bruger` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `navn` varchar(255) NOT NULL,
  `kodeord` varchar(255) NOT NULL,
  `admin` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data dump for tabellen `bruger`
--

INSERT INTO `bruger` (`id_bruger`, `email`, `navn`, `kodeord`, `admin`) VALUES
(1, 'kim1@k-bohn.dk', 'Kim K Bohn1', '070eff61e0554c4406b711f8c628b3ac636ee35a5d621ad49f08c9be0bc15e2e4f2e28baa02ff3c7fc8714f0bd28a1221674979e8da1e16d7042bd65822ab1c6', 'ja'),
(2, 'kim.k.b@hotmail.com', 'Kim B', '34bed333329c740437b7b77cc79efb1ada00b53919868d0724bdbfcb9f885c8179e49211c7acaef7dcb16146de43171d2bd8b5e783a615f32af31640ae329e83', 'nej'),
(3, 'kim@kim.dk', 'Kim', '070eff61e0554c4406b711f8c628b3ac636ee35a5d621ad49f08c9be0bc15e2e4f2e28baa02ff3c7fc8714f0bd28a1221674979e8da1e16d7042bd65822ab1c6', 'ja'),
(4, 'kim@bohn.dk', 'Kim Bohn', '34bed333329c740437b7b77cc79efb1ada00b53919868d0724bdbfcb9f885c8179e49211c7acaef7dcb16146de43171d2bd8b5e783a615f32af31640ae329e83', 'nej'),
(5, 'kim@k-bohn.dk', 'Kim K Bohn', '34bed333329c740437b7b77cc79efb1ada00b53919868d0724bdbfcb9f885c8179e49211c7acaef7dcb16146de43171d2bd8b5e783a615f32af31640ae329e83', 'ja'),
(17, 'kode@test.dk', 'kodetest', '34bed333329c740437b7b77cc79efb1ada00b53919868d0724bdbfcb9f885c8179e49211c7acaef7dcb16146de43171d2bd8b5e783a615f32af31640ae329e83', 'nej'),
(18, 'underviser@skole.dk', 'Underviser', '34bed333329c740437b7b77cc79efb1ada00b53919868d0724bdbfcb9f885c8179e49211c7acaef7dcb16146de43171d2bd8b5e783a615f32af31640ae329e83', 'ja'),
(19, 'sensor@skole.dk', 'Sensor', '34bed333329c740437b7b77cc79efb1ada00b53919868d0724bdbfcb9f885c8179e49211c7acaef7dcb16146de43171d2bd8b5e783a615f32af31640ae329e83', 'ja');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `isometri`
--

CREATE TABLE `isometri` (
  `id_isometri` int(11) NOT NULL,
  `isometrinavn` varchar(255) NOT NULL,
  `id_projekt` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data dump for tabellen `isometri`
--

INSERT INTO `isometri` (`id_isometri`, `isometrinavn`, `id_projekt`) VALUES
(1, 'mobel03.svg', '10'),
(2, 'mobel04.svg', '11'),
(3, 'mobel01.svg', '13'),
(4, 'mobel02.svg', '12'),
(6, 'mobel-test-01.svg', '11'),
(7, 'mobel-halv-export-01.svg', '11');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `projekter`
--

CREATE TABLE `projekter` (
  `id_projekt` int(11) NOT NULL,
  `projektnavn` varchar(255) NOT NULL,
  `ejer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data dump for tabellen `projekter`
--

INSERT INTO `projekter` (`id_projekt`, `projektnavn`, `ejer`) VALUES
(10, 'Strandparken', '1'),
(11, 'Moebelfabrikken', '1'),
(12, 'Amalieparken', '1'),
(13, 'Rolighedsvej', '1');

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `boligliste`
--
ALTER TABLE `boligliste`
  ADD PRIMARY KEY (`id_bolig`);

--
-- Indeks for tabel `bruger`
--
ALTER TABLE `bruger`
  ADD PRIMARY KEY (`id_bruger`);

--
-- Indeks for tabel `isometri`
--
ALTER TABLE `isometri`
  ADD PRIMARY KEY (`id_isometri`);

--
-- Indeks for tabel `projekter`
--
ALTER TABLE `projekter`
  ADD PRIMARY KEY (`id_projekt`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `boligliste`
--
ALTER TABLE `boligliste`
  MODIFY `id_bolig` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- Tilføj AUTO_INCREMENT i tabel `bruger`
--
ALTER TABLE `bruger`
  MODIFY `id_bruger` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Tilføj AUTO_INCREMENT i tabel `isometri`
--
ALTER TABLE `isometri`
  MODIFY `id_isometri` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tilføj AUTO_INCREMENT i tabel `projekter`
--
ALTER TABLE `projekter`
  MODIFY `id_projekt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
